#ifndef CDYNAMIXEL_H_
#define CDYNAMIXEL_H_

#include <threemxl/platform/hardware/dynamixel/dynamixel/Dynamixel.h>

#endif /* CDYNAMIXEL_H_ */
