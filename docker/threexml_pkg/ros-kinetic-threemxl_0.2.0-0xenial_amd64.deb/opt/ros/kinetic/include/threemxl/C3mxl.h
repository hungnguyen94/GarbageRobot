#ifndef C3MXL_H_
#define C3MXL_H_

#include <threemxl/platform/hardware/dynamixel/3mxl/3mxl.h>

#endif /* C3MXL_H_ */
