// Auto-generated. Do not edit!

// (in-package shared_serial.srv)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ConnectRequest {
  constructor() {
    this.timeout = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type ConnectRequest
    // Serialize message field [timeout]
    bufferInfo = _serializer.float32(obj.timeout, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type ConnectRequest
    let tmp;
    let len;
    let data = new ConnectRequest();
    // Deserialize message field [timeout]
    tmp = _deserializer.float32(buffer);
    data.timeout = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a service object
    return 'shared_serial/ConnectRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8e929ace7fd80dc265b8b96078f41e82';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    float32 timeout
    
    
    `;
  }

};

class ConnectResponse {
  constructor() {
    this.socket = 0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type ConnectResponse
    // Serialize message field [socket]
    bufferInfo = _serializer.int32(obj.socket, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type ConnectResponse
    let tmp;
    let len;
    let data = new ConnectResponse();
    // Deserialize message field [socket]
    tmp = _deserializer.int32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a service object
    return 'shared_serial/ConnectResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '89a3ab074876917505d8ad961102ef9f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    int32   socket
    
    
    `;
  }

};

module.exports = {
  Request: ConnectRequest,
  Response: ConnectResponse
};
