// Auto-generated. Do not edit!

// (in-package shared_serial.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------

class Send {
  constructor() {
    this.socket = 0;
    this.data = [];
    this.timeout = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type Send
    // Serialize message field [socket]
    bufferInfo = _serializer.uint32(obj.socket, bufferInfo);
    // Serialize the length for message field [data]
    bufferInfo = _serializer.uint32(obj.data.length, bufferInfo);
    // Serialize message field [data]
    bufferInfo.buffer.push(obj.data);
    bufferInfo.length += obj.data.length;
    // Serialize message field [timeout]
    bufferInfo = _serializer.float32(obj.timeout, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type Send
    let tmp;
    let len;
    let data = new Send();
    // Deserialize message field [socket]
    tmp = _deserializer.uint32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    // Deserialize array length for message field [data]
    tmp = _deserializer.uint32(buffer);
    len = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [data]
    data.data = buffer.slice(0, len);
    buffer =  buffer.slice(len);
    // Deserialize message field [timeout]
    tmp = _deserializer.float32(buffer);
    data.timeout = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'shared_serial/Send';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9488c54395f85f0662ca59801f32b45a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Send data to serial port.
    
    # Eeither 0 (connectionless) or an unexpired socket identifier
    # from an earlier communication.
    uint32  socket
    
    # Data to be sent.
    uint8[] data
    
    # Number of seconds to keep the port locked after this communication.
    float32 timeout
    
    `;
  }

};

module.exports = Send;
