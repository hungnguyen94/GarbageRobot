// Auto-generated. Do not edit!

// (in-package shared_serial.srv)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class RecvRequest {
  constructor() {
    this.socket = 0;
    this.length = 0;
    this.recv_timeout = 0.0;
    this.sock_timeout = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type RecvRequest
    // Serialize message field [socket]
    bufferInfo = _serializer.uint32(obj.socket, bufferInfo);
    // Serialize message field [length]
    bufferInfo = _serializer.uint32(obj.length, bufferInfo);
    // Serialize message field [recv_timeout]
    bufferInfo = _serializer.float32(obj.recv_timeout, bufferInfo);
    // Serialize message field [sock_timeout]
    bufferInfo = _serializer.float32(obj.sock_timeout, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type RecvRequest
    let tmp;
    let len;
    let data = new RecvRequest();
    // Deserialize message field [socket]
    tmp = _deserializer.uint32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [length]
    tmp = _deserializer.uint32(buffer);
    data.length = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [recv_timeout]
    tmp = _deserializer.float32(buffer);
    data.recv_timeout = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [sock_timeout]
    tmp = _deserializer.float32(buffer);
    data.sock_timeout = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a service object
    return 'shared_serial/RecvRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c05d3c907840837e419db15be31d15b6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    uint32  socket
    
    
    uint32  length
    
    
    float32 recv_timeout
    
    
    float32 sock_timeout
    
    
    `;
  }

};

class RecvResponse {
  constructor() {
    this.socket = 0;
    this.data = [];
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type RecvResponse
    // Serialize message field [socket]
    bufferInfo = _serializer.uint32(obj.socket, bufferInfo);
    // Serialize the length for message field [data]
    bufferInfo = _serializer.uint32(obj.data.length, bufferInfo);
    // Serialize message field [data]
    bufferInfo.buffer.push(obj.data);
    bufferInfo.length += obj.data.length;
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type RecvResponse
    let tmp;
    let len;
    let data = new RecvResponse();
    // Deserialize message field [socket]
    tmp = _deserializer.uint32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    // Deserialize array length for message field [data]
    tmp = _deserializer.uint32(buffer);
    len = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [data]
    data.data = buffer.slice(0, len);
    buffer =  buffer.slice(len);
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a service object
    return 'shared_serial/RecvResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9aa8c2746a0876552ecc2a81ad0d58a5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    uint32  socket
    
    
    uint8[] data
    
    
    `;
  }

};

module.exports = {
  Request: RecvRequest,
  Response: RecvResponse
};
