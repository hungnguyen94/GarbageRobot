// Auto-generated. Do not edit!

// (in-package shared_serial.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------

class Close {
  constructor() {
    this.socket = 0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type Close
    // Serialize message field [socket]
    bufferInfo = _serializer.uint32(obj.socket, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type Close
    let tmp;
    let len;
    let data = new Close();
    // Deserialize message field [socket]
    tmp = _deserializer.uint32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'shared_serial/Close';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '82ff2df0785f8985963dadf1a996d34e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Release serial port lock.
    
    # Socket identifier from an earlier communication.
    uint32 socket
    
    `;
  }

};

module.exports = Close;
