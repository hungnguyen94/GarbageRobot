// Auto-generated. Do not edit!

// (in-package shared_serial.msg)


"use strict";

let _serializer = require('../base_serialize.js');
let _deserializer = require('../base_deserialize.js');
let _finder = require('../find.js');

//-----------------------------------------------------------

class Flush {
  constructor() {
    this.socket = 0;
    this.timeout = 0.0;
  }

  static serialize(obj, bufferInfo) {
    // Serializes a message object of type Flush
    // Serialize message field [socket]
    bufferInfo = _serializer.uint32(obj.socket, bufferInfo);
    // Serialize message field [timeout]
    bufferInfo = _serializer.float32(obj.timeout, bufferInfo);
    return bufferInfo;
  }

  static deserialize(buffer) {
    //deserializes a message object of type Flush
    let tmp;
    let len;
    let data = new Flush();
    // Deserialize message field [socket]
    tmp = _deserializer.uint32(buffer);
    data.socket = tmp.data;
    buffer = tmp.buffer;
    // Deserialize message field [timeout]
    tmp = _deserializer.float32(buffer);
    data.timeout = tmp.data;
    buffer = tmp.buffer;
    return {
      data: data,
      buffer: buffer
    }
  }

  static datatype() {
    // Returns string type for a message object
    return 'shared_serial/Flush';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '998caebd95b1820bc38f9812484a09de';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Flush serial port.
    
    # Eeither 0 (connectionless) or an unexpired socket identifier
    # from an earlier communication.
    uint32 socket
    
    # Number of seconds to keep the port locked after this communication.
    float32 timeout
    
    `;
  }

};

module.exports = Flush;
